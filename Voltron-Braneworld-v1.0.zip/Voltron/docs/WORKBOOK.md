# AuraXLSL Workbook Reference
Semantic sheets expose THINK, PLAN, MEMORY, WORLD, SIMULATE and EXTRACT_LORA operations.
