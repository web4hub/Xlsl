# BrainWorld Runtime
BrainWorld coordinates perception, hippocampal retrieval, cortical reasoning, planning and memory writes.
