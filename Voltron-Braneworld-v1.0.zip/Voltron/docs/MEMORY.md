# Memory Graph
Entities: Person, Object, Location, Event, Emotion, Skill. Relations: THINKS, KNOWS, CREATED, OBSERVED, PREDICTS, REMEMBERS, USES.
