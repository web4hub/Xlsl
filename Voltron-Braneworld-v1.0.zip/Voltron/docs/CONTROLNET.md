# ControlNet / LoRA
Adapter extraction is represented as a routing interface. Model weights remain external to the reference runtime.
