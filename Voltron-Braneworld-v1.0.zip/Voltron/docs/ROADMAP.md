# Roadmap
1. XLSL parser/evaluator. 2. Persistent vector graph. 3. Model-provider adapters. 4. Vision/audio/robotics backends. 5. Rust/Python FFI. 6. Provenance and Web4 identity.
