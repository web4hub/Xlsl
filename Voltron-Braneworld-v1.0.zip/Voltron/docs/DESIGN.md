# Design
Observe → Encode → Retrieve → Reason → Plan → Execute → Store.
Python is the reference implementation; Rust defines the runtime boundary.
