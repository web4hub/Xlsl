#[derive(Debug, Clone)] pub struct Plan { pub goal:String, pub steps:Vec<String> }
#[derive(Debug, Clone)] pub struct NeuralOutput { pub action:Plan, pub memory_id:String }
pub struct BrainWorldRuntime { pub memory_count:usize }
impl BrainWorldRuntime { pub fn new()->Self{Self{memory_count:0}} pub fn think(&mut self,input:&str)->NeuralOutput{ self.memory_count+=1; NeuralOutput{action:Plan{goal:input.into(),steps:vec!["observe".into(),"reason".into(),"act".into()]},memory_id:format!("plan:{}",self.memory_count)}}}
