pub struct MemoryGraph;
