import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]))
from braneworld.engine import BrainWorldRuntime
def test_think():
    r=BrainWorldRuntime(); o=r.think({'modality':'text','payload':'hello world','features':[1.0,0.0]})
    assert o.action['goal']=='hello world'; assert o.memory_id=='plan:1'
def test_memory():
    r=BrainWorldRuntime(); r.think({'payload':'first','features':[1,0]}); r.think({'payload':'second','features':[0,1]})
    assert len(r.hippocampus.graph.nodes)==2
