from dataclasses import dataclass
from .cortex import Cortex
from .hippocampus import Hippocampus
from .planner import Planner
from .perception import PerceptionEngine
@dataclass
class NeuralOutput:
    action: dict
    memory_id: str|None
class BrainWorldRuntime:
    def __init__(self): self.cortex=Cortex(); self.hippocampus=Hippocampus(); self.planner=Planner(); self.perception=PerceptionEngine()
    def think(self, neural_input: dict)->NeuralOutput:
        p=self.perception.observe(neural_input); memories=self.hippocampus.retrieve(p); reasoning=self.cortex.reason(p,memories); plan=self.planner.plan(reasoning); mid=self.hippocampus.store(plan)
        return NeuralOutput({'goal':plan.goal,'steps':plan.steps},mid)
