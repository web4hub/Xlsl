from dataclasses import dataclass
@dataclass
class Plan:
    goal: str
    steps: list[str]
class Planner:
    def plan(self, reasoning): return Plan(reasoning.conclusion or 'idle',['observe','reason','act'])
