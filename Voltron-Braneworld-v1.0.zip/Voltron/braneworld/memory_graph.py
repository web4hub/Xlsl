from dataclasses import dataclass, field
from math import sqrt
from typing import Any

@dataclass
class MemoryNode:
    id: str
    kind: str
    embedding: list[float] = field(default_factory=list)
    data: Any = None
    edges: list[tuple[str, str]] = field(default_factory=list)
    def connect(self, relation: str, node_id: str) -> None:
        self.edges.append((relation, node_id))

class MemoryGraph:
    def __init__(self): self.nodes: dict[str, MemoryNode] = {}
    def add(self, node: MemoryNode) -> None: self.nodes[node.id] = node
    def connect(self, source: str, relation: str, target: str) -> None: self.nodes[source].connect(relation, target)
    def retrieve(self, embedding: list[float], limit: int = 5) -> list[MemoryNode]:
        def sim(a,b):
            if not a or not b or len(a)!=len(b): return 0.0
            dot=sum(x*y for x,y in zip(a,b)); na=sqrt(sum(x*x for x in a)); nb=sqrt(sum(y*y for y in b))
            return dot/(na*nb) if na and nb else 0.0
        return sorted(self.nodes.values(), key=lambda n: sim(n.embedding, embedding), reverse=True)[:limit]
    def store(self, node: MemoryNode) -> None: self.add(node)
