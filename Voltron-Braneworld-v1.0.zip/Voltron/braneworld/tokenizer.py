import re
TOKEN = re.compile(r"[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|[^\s]")
def tokenize(text: str) -> list[str]: return TOKEN.findall(text)
