from .memory_graph import MemoryGraph, MemoryNode
class Hippocampus:
    def __init__(self): self.graph=MemoryGraph()
    def retrieve(self, perception): return self.graph.retrieve(perception.features)
    def store(self, plan):
        node_id=f'plan:{len(self.graph.nodes)+1}'; self.graph.store(MemoryNode(node_id,'Plan',data={'goal':plan.goal,'steps':plan.steps})); return node_id
