from .tokenizer import tokenize
def reason(text: str, memories=None): return {'tokens':tokenize(text),'memories':memories or [],'mode':'symbolic-reference'}
