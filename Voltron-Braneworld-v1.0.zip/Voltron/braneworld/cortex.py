from dataclasses import dataclass
from .tokenizer import tokenize
@dataclass
class Reasoning:
    tokens: list[str]
    memory_ids: list[str]
    conclusion: str
class Cortex:
    def reason(self, perception, memory) -> Reasoning:
        tokens=tokenize(str(perception.payload)); return Reasoning(tokens,[m.id for m in memory], ' '.join(tokens) if tokens else 'NO_SIGNAL')
