from dataclasses import dataclass
from typing import Any
@dataclass
class Perception:
    modality: str
    payload: Any
    features: list[float]
class PerceptionEngine:
    def observe(self, neural_input: dict) -> Perception:
        return Perception(neural_input.get('modality','text'), neural_input.get('payload', neural_input), neural_input.get('features', []))
