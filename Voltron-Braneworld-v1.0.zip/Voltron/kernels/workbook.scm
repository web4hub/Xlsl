(define (run-workbook name input) (list 'workbook name input))
