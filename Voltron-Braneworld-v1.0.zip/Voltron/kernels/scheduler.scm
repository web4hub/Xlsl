(define (schedule task priority) (list 'schedule task priority))
(define (tick runtime) (list 'tick runtime))
