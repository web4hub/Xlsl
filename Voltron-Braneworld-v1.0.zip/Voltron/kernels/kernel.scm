(define (think input memory) (list 'think input memory))
(define (plan reasoning) (list 'plan reasoning))
(define (execute plan) (list 'execute plan))
(define (store value) (list 'store value))
