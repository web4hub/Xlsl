def extract_lora(base_state, control_state, rank=16): return {"rank":rank,"base":base_state,"control":control_state}
