def condition(latents, controls): return {'latents':latents,'controls':controls}
