def apply(image, depth=None, pose=None): return {'image':image,'depth':depth,'pose':pose}
