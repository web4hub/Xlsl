def encode(tokens): return list(range(len(tokens)))
