def normalize(vector):
    s=sum(x*x for x in vector)**0.5
    return [x/s for x in vector] if s else vector
