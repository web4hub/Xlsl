# Voltron Braneworld Model

AuraXLSL Workbook-native BrainWorld runtime for the NeuroMindModel ecosystem.

Framework: NeuroMindModel  
Workbook runtime: AuraXLSL / XLSL  
Engine: BrainWorld Runtime (BWR)  
Namespace: `neuromindmodel.braneworld`  
Codename: Voltron

The reference implementation is dependency-light: Python provides the executable cognitive pipeline and Rust mirrors the runtime boundary.
